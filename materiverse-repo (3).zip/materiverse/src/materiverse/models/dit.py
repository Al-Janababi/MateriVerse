"""Crystal diffusion transformer with Pauli-motivated attention bias (PyTorch).

Invariances by construction
---------------------------
* Rotation: the lattice enters only through (a, b, c, alpha, beta, gamma), which are rotation invariant.
* Translation: atom features contain no absolute positions; geometry enters only through minimum-image
  *relative* displacements and distances, so a global shift of all fractional coordinates leaves the
  outputs unchanged.
* Permutation: no positional encodings over atom order; attention and edge sums are permutation equivariant.
This is an invariant-features design, not a full steerable SE(3) architecture.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def lattice_matrix_torch(lengths: torch.Tensor, angles_deg: torch.Tensor) -> torch.Tensor:
    """(B,3),(B,3) -> (B,3,3); rows are lattice vectors (matches materiverse.crystal.lattice_matrix)."""
    a, b, c = lengths.unbind(-1)
    al, be, ga = torch.deg2rad(angles_deg).unbind(-1)
    cos_al, cos_be, cos_ga, sin_ga = torch.cos(al), torch.cos(be), torch.cos(ga), torch.sin(ga)
    zeros = torch.zeros_like(a)
    v1 = torch.stack([a, zeros, zeros], -1)
    v2 = torch.stack([b * cos_ga, b * sin_ga, zeros], -1)
    cx = c * cos_be
    cy = c * (cos_al - cos_be * cos_ga) / sin_ga
    cz = torch.sqrt(torch.clamp(c * c - cx * cx - cy * cy, min=1e-8))
    v3 = torch.stack([cx, cy, cz], -1)
    return torch.stack([v1, v2, v3], -2)


def encode_lattice(lengths: torch.Tensor, angles_deg: torch.Tensor) -> torch.Tensor:
    """[log a, log b, log c, alpha/90-1, beta/90-1, gamma/90-1]; the all-right-angle cell has zero angle entries."""
    return torch.cat([torch.log(lengths), angles_deg / 90.0 - 1.0], dim=-1)


def decode_lattice(lat: torch.Tensor):
    lengths = torch.exp(torch.clamp(lat[..., :3], -2.0, 5.0))
    angles = torch.clamp((lat[..., 3:] + 1.0) * 90.0, 20.0, 160.0)
    return lengths, angles


def pair_geometry(frac: torch.Tensor, lattice: torch.Tensor):
    """d[b,i,j] = wrapped(f_j - f_i) (fractional) and Euclidean minimum-image distances (Angstrom)."""
    d = frac[:, None, :, :] - frac[:, :, None, :]
    d = d - torch.round(d)
    cart = torch.einsum("bijk,bkl->bijl", d, lattice)
    dist = torch.sqrt((cart ** 2).sum(-1) + 1e-12)
    return d, dist


def pauli_bias_torch(dist: torch.Tensor, d_min: float = 1.0, mode: str = "soft") -> torch.Tensor:
    """Torch counterpart of materiverse.pauli.pauli_bias; dist is (B,N,N)."""
    if mode == "off":
        return torch.zeros_like(dist)
    n = dist.shape[-1]
    eye = torch.eye(n, dtype=torch.bool, device=dist.device)[None]
    if mode == "hard":
        close = (dist < d_min) & ~eye
        return torch.where(close, torch.full_like(dist, float("-inf")), torch.zeros_like(dist))
    if mode == "soft":
        p = -torch.clamp(d_min - dist, min=0.0) / d_min
        return torch.where(eye, torch.zeros_like(dist), p)
    raise ValueError(f"unknown mode '{mode}'")


def rbf_expand(dist: torch.Tensor, centers: torch.Tensor, gamma: float) -> torch.Tensor:
    return torch.exp(-gamma * (dist[..., None] - centers) ** 2)


class TimestepEmbedder(nn.Module):
    def __init__(self, dim: int, freq_dim: int = 128):
        super().__init__()
        self.freq_dim = freq_dim
        self.mlp = nn.Sequential(nn.Linear(freq_dim, dim), nn.SiLU(), nn.Linear(dim, dim))

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        half = self.freq_dim // 2
        freqs = torch.exp(-math.log(10000.0) * torch.arange(half, device=t.device, dtype=torch.float32) / half)
        args = t.float()[:, None] * 1000.0 * freqs[None]
        return self.mlp(torch.cat([torch.cos(args), torch.sin(args)], dim=-1))


class BiasedSelfAttention(nn.Module):
    """Multi-head attention with a learned geometric bias and the Pauli exclusion bias alpha * P."""

    def __init__(self, dim: int, heads: int, rbf_dim: int):
        super().__init__()
        assert dim % heads == 0
        self.h, self.dh = heads, dim // heads
        self.qkv = nn.Linear(dim, 3 * dim)
        self.proj = nn.Linear(dim, dim)
        self.geo = nn.Linear(rbf_dim, heads)
        self.alpha_raw = nn.Parameter(torch.zeros(heads))   # alpha = softplus(alpha_raw) > 0

    def forward(self, x, rbf, pauli_p, mask):
        B, N, D = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.h, self.dh).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]                       # (B,H,N,Dh)
        logits = q @ k.transpose(-1, -2) / math.sqrt(self.dh)   # (B,H,N,N)
        logits = logits + self.geo(rbf).permute(0, 3, 1, 2)
        if pauli_p is not None:
            alpha = F.softplus(self.alpha_raw).view(1, self.h, 1, 1)
            logits = logits + alpha * pauli_p[:, None]
        logits = logits.masked_fill(~mask[:, None, None, :], float("-inf"))
        w = torch.softmax(logits, dim=-1)
        out = (w @ v).transpose(1, 2).reshape(B, N, D)
        return self.proj(out)


class DiTBlock(nn.Module):
    """DiT block with adaLN-Zero conditioning (Peebles & Xie, 2023)."""

    def __init__(self, dim: int, heads: int, rbf_dim: int, mlp_ratio: int = 4):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)
        self.attn = BiasedSelfAttention(dim, heads, rbf_dim)
        self.norm2 = nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)
        self.mlp = nn.Sequential(nn.Linear(dim, mlp_ratio * dim), nn.GELU(), nn.Linear(mlp_ratio * dim, dim))
        self.ada = nn.Sequential(nn.SiLU(), nn.Linear(dim, 6 * dim))
        nn.init.zeros_(self.ada[1].weight)
        nn.init.zeros_(self.ada[1].bias)

    def forward(self, x, c, rbf, pauli_p, mask):
        s1, b1, g1, s2, b2, g2 = self.ada(c)[:, None, :].chunk(6, dim=-1)
        x = x + g1 * self.attn(self.norm1(x) * (1 + s1) + b1, rbf, pauli_p, mask)
        x = x + g2 * self.mlp(self.norm2(x) * (1 + s2) + b2)
        return x


class CrystalDiT(nn.Module):
    """Denoiser for (relaxed one-hot species, lattice parameters, fractional coordinates).

    forward(species_t, lat_t, frac_t, t, mask, cond=None) returns
      eps_species (B,N,K)  noise prediction for the relaxed one-hot species
      eps_lat     (B,6)    noise prediction for the (normalised) lattice parameters
      coord_out   (B,N,3)  sigma_t * score of the wrapped-normal kernel (translation invariant, permutation equivariant)
    """

    def __init__(self, num_species=100, dim=256, depth=6, heads=8, rbf_dim=16, d_max=8.0,
                 pauli_mode="soft", d_min=1.0, edge_dim=64, cond_dim=0):
        super().__init__()
        self.num_species, self.pauli_mode, self.d_min = num_species, pauli_mode, d_min
        self.species_in = nn.Linear(num_species, dim)
        self.lat_in = nn.Linear(6, dim)
        self.time = TimestepEmbedder(dim)
        self.cond = nn.Linear(cond_dim, dim) if cond_dim > 0 else None
        self.blocks = nn.ModuleList([DiTBlock(dim, heads, rbf_dim) for _ in range(depth)])
        self.final_norm = nn.LayerNorm(dim, eps=1e-6)
        self.species_out = nn.Linear(dim, num_species)
        self.edge_i, self.edge_j = nn.Linear(dim, edge_dim), nn.Linear(dim, edge_dim)
        self.edge_r = nn.Linear(rbf_dim, edge_dim)
        self.edge_out = nn.Linear(edge_dim, 1)
        self.lat_out = nn.Sequential(nn.Linear(dim, dim), nn.SiLU(), nn.Linear(dim, 6))
        self.register_buffer("rbf_centers", torch.linspace(0.0, d_max, rbf_dim))
        self.rbf_gamma = 0.5 / (d_max / rbf_dim) ** 2
        self.register_buffer("lat_mean", torch.zeros(6))
        self.register_buffer("lat_std", torch.ones(6))

    def set_lattice_stats(self, mean: torch.Tensor, std: torch.Tensor):
        self.lat_mean.copy_(mean)
        self.lat_std.copy_(std)

    def forward(self, species_t, lat_t, frac_t, t, mask, cond=None):
        lat_raw = lat_t * self.lat_std + self.lat_mean
        lengths, angles = decode_lattice(lat_raw)
        lattice = lattice_matrix_torch(lengths, angles)
        d_frac, dist = pair_geometry(frac_t, lattice)
        rbf = rbf_expand(dist, self.rbf_centers, self.rbf_gamma)
        pair_mask = mask[:, :, None] & mask[:, None, :]
        p = pauli_bias_torch(dist, self.d_min, self.pauli_mode)
        p = torch.where(pair_mask, p, torch.zeros_like(p))     # never let padding create all-masked rows
        c = self.time(t) + self.lat_in(lat_t)
        if self.cond is not None and cond is not None:
            c = c + self.cond(cond)
        x = self.species_in(species_t) + c[:, None, :]
        for blk in self.blocks:
            x = blk(x, c, rbf, p, mask)
        x = self.final_norm(x)
        m = mask[..., None].to(x.dtype)
        eps_species = self.species_out(x) * m
        e = F.silu(self.edge_i(x)[:, :, None, :] + self.edge_j(x)[:, None, :, :] + self.edge_r(rbf))
        w = self.edge_out(e) * pair_mask[..., None].to(x.dtype)               # (B,N,N,1)
        coord_out = (w * d_frac).sum(dim=2)                                   # sum_j w_ij (f_j - f_i)
        pooled = (x * m).sum(1) / m.sum(1).clamp(min=1.0)
        eps_lat = self.lat_out(pooled)
        return eps_species, eps_lat, coord_out
