"""MateriVerse reference implementation (see README for scope and limitations)."""
__version__ = "0.1.0"
